<style>
<?php include './assets/css/insta_feed.css'; ?>
</style>
<?php 
require_once 'classes/class-instagram.php'; 
?>






